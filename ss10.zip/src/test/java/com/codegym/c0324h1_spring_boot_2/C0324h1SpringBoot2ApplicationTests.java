package com.codegym.c0324h1_spring_boot_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C0324h1SpringBoot2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
